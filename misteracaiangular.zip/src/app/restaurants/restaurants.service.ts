import { Injectable } from '@angular/core';
import { Restaurant } from './restaurant/restaurant.model';
import { DBLINK } from '../../../app.api';
import {Http} from '@angular/http'
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {ErrorHandler} from '../app.error-handler';
import { MenuItem } from 'app/restaurant-detail/menu-item/menu-item.model';


@Injectable()
export class RestaurantsService {

 

  constructor(private http: Http ) { }

  restaurants(): Observable<Restaurant[]>{
    return this.http.get(`${DBLINK}/restaurants`)
    .map(response => response.json())
    .catch(ErrorHandler.handlerError)
  }

  restaurantById(id: string): Observable<Restaurant>{
    return this.http.get(`${DBLINK}/restaurants/${id}`)
    .map(response => response.json())
    .catch(ErrorHandler.handlerError)
  }

reviewsOfRestaurant (id: string): Observable<any>{
  return this.http.get(`${DBLINK}/restaurants/${id}/reviews`)
  .map(response => response.json())
  .catch(ErrorHandler.handlerError)
}

menuOfRestaurant (id: string): Observable<MenuItem[]> {
  return this.http.get(`${DBLINK}/restaurants/${id}/menu`)
  .map(response => response.json())
  .catch(ErrorHandler.handlerError)
}

}
